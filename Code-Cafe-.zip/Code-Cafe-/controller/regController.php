<?php
require_once('../model/db.php');
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ensure all fields are set
    if (isset($_POST['user_name']) && isset($_POST['password']) && isset($_POST['email']) && isset($_POST['dob']) && isset($_POST['phone'])) {
        // Sanitize and assign variables
        $user_name = $_POST['user_name'];
        $password = $_POST['password'];
        $email = $_POST['email'];
        $dob = $_POST['dob'];
        $phone = $_POST['phone'];
        // Assume you have a connection file
        // require_once 'db.php'; // Ensure this file contains the connection to the database

        $stmt = $con->prepare("INSERT INTO members (user_name, password, email, dob, phone) VALUES (?, ?, ?, ?, ?)");

        if (!$stmt) {
            die("Prepare failed: " . $con->error);
        }

        $stmt->bind_param("sssss", $user_name, $password, $email, $dob, $phone );

        if ($stmt->execute()) {
            echo "Registration successful!";
        } else {
            echo "Execute failed: " . $stmt->error;
        }

        $stmt->close();
        $con->close();
    } else {
        echo "All fields are required.";
    }
} else {
    echo "Invalid request method.";
}
?>
