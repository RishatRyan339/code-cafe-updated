<?php
// session_start();
// require_once('../model/alldb.php');

// if ($_SERVER['REQUEST_METHOD'] == 'POST') {
//     $email = $_POST['email'];
//     $password = $_POST['password'];

//     if (auth($email, $password)) {
//         // Successful login
//         $_SESSION['user_email'] = $email;
//         header("Location: home.php"); // Redirect to a secure page
//         exit();
//     } else {
//         // Failed login
//         $_SESSION['error'] = "Invalid email or password";
//         header("Location: ../view/login.php"); // Redirect back to login page
//         exit();
//     }
// } else {
//     // Not a POST request
//     header("Location: login.php"); // Redirect back to login page
//     exit();
// }
?>


<?php 
    session_start();
    require_once('../model/alldb.php');
  
    $email= $_REQUEST['email'];
    $password= $_REQUEST['password'];
  
  
  
  
  
    if($email == "" || $password == ""){
        echo"null username/password";


 
    }else{ 
     
    /* $con = mysqli_connect('localhost','root','','web_tech');*/    
     
        $status = auth($email, $password);
        if($status){
            $_SESSION['error'] = " true";
            header('location: home.php');



        /* 
     } else if($username ==$_SESSION['user']['username'] && $password ==$_SESSION['user']['password']){
            $_SESSION['flag'] = "true";
            header('location: ../view/home.php');
*/
        }else{
            echo"invalid user!";
        }

    }
     ?>