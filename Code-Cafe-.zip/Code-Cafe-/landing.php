
<?php 


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="view/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">
   
</head>
<body>



<header class="header">
        <a href="" class="logo" id="logo">
            <img src="view/WebTech/BRANDd-1-01.png" alt="logo" height="53px" width="194px">
        </a>
    

    
        <nav class="navbar" id="navbar1">
            <a href="#home">home</a>
            <a href="#catalog">catalog</a>
            <a href="#contests">contests</a>
            <a href="#problem">problem set</a> 
            <a href="#ranking">ranking</a>
            <a href="view/login.php">Login</a>
            
            <a href="view/registration.php">register</a>
            
            <a href="" class="logo" id="logo2">
                <img src="view/WebTech/day-and-night.png"height="33px" width="35px">
            </a>
          
            <a href="#english"id="eng">EN</a>
        </nav>
        
            </header>


            <div class="hero">
                <h2>Hello </h2>
                <p>Test Your Skills <br> Complete in challenges, solve problems<br> and improve your skills</p>
                <button class="btn">Start Coding</button>
            </div>
    








</div>
</div>
</body>
</html>